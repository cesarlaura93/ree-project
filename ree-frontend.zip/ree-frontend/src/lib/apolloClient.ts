import { ApolloClient, InMemoryCache } from "@apollo/client";

const client = new ApolloClient({
    uri: process.env.NEXT_PUBLIC_GRAPHQL_ENDPOINT || "http://localhost:8080/graphql", // Asegúrate de que esta variable de entorno esté configurada o cambia la URL
    cache: new InMemoryCache(),
});

export default client; 